public class StringDemo {
    public static void main(String[] args) {
        String name = "Amit"; // String Literal
        String name2 = "Amit";
        String name3 = new String("Amit").intern();
        System.out.println(name==name2); // true
        System.out.println(name == name3); // true
        StringBuffer sql = new StringBuffer("select * from product");
        double price = 9000;
        if(price>0){
            sql = sql .append( " where price>=").append(price);
        }
    }
}
