import java.math.BigDecimal;
import java.math.BigInteger;

public class RefDemo {
    public static void main(String[] args) {
        String name = "Amit";
        System.out.println(name.toUpperCase());
        int x = 100;
        Integer y = 200;
        Double rr ;
        Integer f = Integer.valueOf(x); // Boxing
        String v = y.toString();
        double r = y.doubleValue(); // UnBoxing
        BigInteger b = new BigInteger("10000000000000000000000");
        BigInteger b2 = new BigInteger("43434343433232533432423");
        BigInteger b3 = b.add(b2);
        System.out.println(b3);
        BigDecimal bb = new BigDecimal("534545534534534.32423434");




    }
}
