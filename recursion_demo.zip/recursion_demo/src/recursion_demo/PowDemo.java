package recursion_demo;

public class PowDemo {
	static int power(int num, int pow) {
		if(pow == 0) {
			return 1;
		}
		int smallResult = power(num, pow-1);
		return num * smallResult;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 2 ^ 5 = 32;
		int result = power(2, 5);
		System.out.println(result);

	}

}
