package strings;

public class PalindromGreatest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i = 12300; 
		// 12321
		while(true) {
			int num = i; //copy so i can't destroy
			int reverse = 0;
			while(num!=0) {
				int rem = num % 10;
				reverse = reverse * 10 + rem;
				num = num/10;
			}
			if(reverse == i) {
				System.out.println("Palindrome " +i);
				return ;
			}
//			else {
//				System.out.println("Not Palindrome "+i +" Rev "+reverse);
//			}
			i++;
		}

	}

}
