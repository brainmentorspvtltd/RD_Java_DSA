package strings;

import java.util.ArrayList;
import java.util.Collections;

public class AlphaNumericSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "a2b4c60d4";
		ArrayList<Integer> digits = new ArrayList<>();
		for(char singleChar : str.toCharArray()) {
			if(Character.isDigit(singleChar)) {
				digits.add(singleChar - '0');
			}
		}
		Collections.sort(digits);
		int index  = 0 ;
		char [] output = str.toCharArray();
		for(int i = 0 ; i<output.length; i++) {
			if(Character.isDigit(output[i])) {
				int digit = digits.get(index);
				output[i] = Character.forDigit(digit, 10); // replace
				index++;
			}
		}
		System.out.println(new String(output));

	}

}
