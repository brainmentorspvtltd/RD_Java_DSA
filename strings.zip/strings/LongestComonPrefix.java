package strings;

public class LongestComonPrefix {
	static String commonCompare(char[] first, char [] second) {
		String commonString = "";
		for(int i = 0; i<first.length && i<second.length; i++) {
			if(first[i] == second[i]) {
				commonString += first[i];
			}
			else {
				break;
			}
		}
		return commonString;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input = "assistant assist assistance";
		//String input = "jammed jambed jampot jambee";
		String words [] = input.split(" ");
		String prefix = "";
		for(int i = 0 ; i<words.length ; i++) {
			char first [] = words[i].toCharArray();
			for(int j = i + 1; j<words.length-1 ; j++) {
				char second[] = words[j].toCharArray();
				String common = commonCompare(first, second);
				if(prefix.length()==0) {
					prefix = common;// first time
				}
				else if (common.length()>0 && prefix.length()> common.length()){
					prefix = common;
				}
			}
		}
		System.out.println(prefix);

	}

}
