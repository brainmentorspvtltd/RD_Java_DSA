package strings;

public class MInRotation {

	public static void main(String[] args) {
		String str = "ProgramJava JavaProgram";
		int count = 0;
		String [] list = str.split(" ");
		String first = list[0];
		String second = list[1];
		int j = second.length();
		for(int i = 0 ; i<j; i++) {
			second = second.substring(1) + second.charAt(0);
			count++;
			if(first.equals(second)){
				System.out.println(count);
				return ;
			}
		}
		System.out.println(-1);
		

	}

}
