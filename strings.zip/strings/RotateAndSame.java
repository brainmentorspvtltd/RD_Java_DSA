package strings;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class RotateAndSame {
	static HashMap<Character, Integer> fillMap(String str){
		HashMap<Character, Integer> map = new HashMap<>();
		for(Character singleChar : str.toCharArray()) {
			int count = map.getOrDefault(singleChar, 0);
			count++;
			map.put(singleChar, count);
		}
		return map;
	}
	public static void main(String[] args) {
		String str = "Laptop toplap".toLowerCase();
		String [] list  = str.split(" ");
		if(list[0].length() != list[1].length()) {
			System.out.println("FALSE");
			return ;
		}
		HashMap<Character, Integer> map1 = fillMap(list[0]);
		HashMap<Character, Integer> map2 = fillMap(list[1]);
		Set<Character> keys = map1.keySet();
		Iterator<Character>  itr = keys.iterator();
		while(itr.hasNext()) {
			Character key = itr.next(); // Give Current Key and move to the next key
			if(map1.get(key) != map2.get(key)) {
				System.out.println("FALSE");
				return ;
			}
		}
		System.out.println("TRUE");
		
		

	}

}
