package strings;

public class UnCommonWords {

	public static void main(String[] args) {
		String str = "the java programming is best \n" + 
	"learning from java for programming\n" +
				"java for programming";
		String lines [] = str.split("\n");
		String firstLineWords [] = lines[0].split(" ");
		int unCommonCount = 0;
		for(String word: firstLineWords) {
			boolean isMatch = false;
			for(int i = 1; i<lines.length; i++) {
				String lineWords [] =lines[i] .split(" ");
				for(String lineWord : lineWords) {
					if(word.equalsIgnoreCase(lineWord)) {
						isMatch   = true;
					}
				} // line words
			} // lines
			if(!isMatch) {
				unCommonCount ++;
			}
		} // First Line
		System.out.println(unCommonCount);

	}

}
