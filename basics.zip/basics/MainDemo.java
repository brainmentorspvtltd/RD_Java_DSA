
/*
Question :
Can we create more than one main method in Java

Answer: We need overload the main method
*/
public class MainDemo {

    public static void main(int x) {
        System.out.println("int main");
    }

    public static void main() {
        System.out.println("main with no args");
    }

    public static void main(String[] args) {
        System.out.println("main method");
        main();
        main(10);
    }
}
