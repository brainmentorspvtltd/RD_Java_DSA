/*
Question : Can we change main method signature in java?
Answer : yes
1. Interchange public and static
2. Array Style Change
3. args change any name
4. Instead of array we can use ... var args argument (Java 1.5)
*/
class MainDemo2 {
    static public void main(String... arr) {

    }
}