/*
 What is Local Variables , and is required to initalize the local variables in Java?
 In Java There is no concept of Garbage Values
*/
public class MainDemo3 {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        int c = a + b;
        System.out.println(c);
    }
}
