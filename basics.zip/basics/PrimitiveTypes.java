/*
What is Primitive Types in Java?
Answer: It is also called as Primary Types (C, C++ Data Types inspired)
It is also called as Value type.

a) Non-Decimal Values
byte, short, int, long
b) Decimal Value
float, double

c) char for single character (2 Byte ) / UNICODE

d) boolean True/False
true - 1
false - 0
1 Byte / 2 Byte - Dependent on O/S to O/S
*/

public class PrimitiveTypes {
    public static void main(String[] args) {
        byte x = 10; // 1 Byte of Data
        byte y = 127;
        byte z = (byte) 130;
        int a = 100;
        System.out.println(z);
        short c = 10000; // 2 byte of data
        int f = 100; // 4 byte (32 bit) 2^ 31
        long g = 1000l; // l or L for long (long Literal) 8 Byte

        float r = 100.20F; // f or F for Float Literal (4 Byte)
        double s = 88.22; // 8 Byte

        char w = 'A'; // 2 Byte
        char q = 'न';

        boolean att = true;

    }
}
