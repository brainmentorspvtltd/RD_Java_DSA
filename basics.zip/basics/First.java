/*
class is a predefine keyword , to make a class.
Usually the class name is same as file name.
But it become compulsory when class name is having public keyword
if the class name is not consist public so the file name can be different
the only problem is
Compile the code with file name e.g javac <FileName>.java
After compile we get a .class file with a name of a class <ClassName>.class
e.g A.java --> class B{}
e.g javac A.java --> B.class
so to run the code i need to remember the class name e.g java B


*/
/*
 Class naming conventions
 1. Start with AlphaBet
 2. Can be Alpha Numeric
 3. Use $ and _ as a special Keyword in class Name
 4. can be start with _ and $
 5. Not use keywords in class Name
 6. Convention is start with Capital letter , e.g PrintWriter, SavingAccount i.e CamelCase
*/
class First {
    // public , static , void , class all are predefine keywords
    /*
     * void means no return type.
     * static means It load the static things when class is loaded.
     * so whenever we issue the java <ClassFileName> command it first load the
     * classes
     * when classes are loading on this phase the static things willbe loaded. so we
     * can say static
     * things are eagerly loaded.
     * so we want main willbe avaliable when class is loading.
     * public - It is for scope ,Actually Java Install in c:\program files in case
     * of windows or in case
     * of mac it install in Library folder and our code usually store in different
     * location. So the main
     * method must be accessiable outside the current folder, so java command can
     * access the main for
     * execution, so that's why we make main as public
     * public says if function is public or class is public so it accessiable
     * outside the folder (package).
     *
     * main - is a function name
     * and it is a String args[] as an Argument
     * these arguments are used for command line purpose. so if u want to give the
     * inputs from the command line use
     * String [] args
     *
     * String - It is a predefine class in Java , Internally collection of chars so
     * we can say it contain char array.
     */
    public static void main(String[] args) {
        /*
         * System is a predefine class coming from java.lang package (Folder) and it is
         * default import it.
         * System class having a private constructor so we can not create the object of
         * System class.
         * System class is also a final class so we can not inherit it.
         * From JDK 1.0 Avaliable
         * It Encapsulate the folllowing
         * 1. InputStream class object e.g in - for taking input from the user
         * 2. PrintStream class object out - for output on console.
         * 3. PrintStream class object err - for err print on console
         * All of three are static and final objects.
         * out object and err object coming from PrintStream class and PrintStream class
         * contains print and println function
         * for output on console.
         *
         * print function - print a String, int , float, double , boolean etc so print
         * function is overloaded function.
         * println function - internally call print function and also called the newLine
         * function for \n
         * println is also a overloaded function.
         */

        System.out.println("Hello Java ");
    }
}