
/*
    What is intern method in String?
    Answer : intern () is placing the String in a pool, so it checking whether the
    string is exist in a pool, if not exist then place it otherwise point it.
*/
public class InternDemo {
    public static void main(String[] args) {
        String name = "Amit".intern();
        String name2 = "Amit"; // by default intern here
        // String name3 = new String("Amit").intern(); // explict specify intern here
        String name3 = new String("Amit");
        System.out.println(name == name2); // true
        System.out.println(name2 == name3); // false

    }
}
