/*
    Question : What is String in Java?
    1. String is a class in Java
    2. String is a final class in Java , so no one can inherit this class
    3. String is internally store in char array e.g char value []
    4. String maintain in String Pool
    5. String object creates either String Literal or new String
    6. String objects are Immutable (Not Modified)

*/

public class StringDemo {
    public static void main(String[] args) {
        String message = "Welcome User";
        String m = "Welcome User";
        String m2 = "Welcome User";
        System.out.println(message == m); // true
        System.out.println(message == m2); // true
        message = "Bye bye User";
        System.out.println(message + " " + m + " " + m2);
        System.out.println(message == m); // false
        System.out.println(message == m2); // false

        // String a = "Amit"; // String Literal // 1 or 0 object
        // // I am Checking Amit is exist in a String Pool or not,
        // // If not exist then create otherwise point the existing one.
        // // name is a variable which store the address / reference of the memory where
        // // Amit String is created.
        // String b = "Amit";
        // System.out.println(a == b);
        // String c = new String("Amit"); // Create a new String everytime in a heap.
        // // 2 or 1 Object
        // System.out.println(a == c);

    }
}
