package com.brainmentors.chatapp.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;



public class Server {
	ServerSocket serverSocket ;
	Socket socket ;
	InputStream in;
	OutputStream out;
	public Server() throws IOException {
		serverSocket = new ServerSocket(9001); // Server ready 
		System.out.println("waiting for the Client....");
		socket = serverSocket.accept();
		in = socket.getInputStream();
		out = socket.getOutputStream();
		System.out.println("Client Joins");
		//socket.close();
		
	}
	public void readMessage() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String inputLine = "";
		while(true) { // Infinite Loop (Main Thread Busy)
			inputLine = br.readLine();
			System.out.println("Message Rec "+inputLine);
		}
		 
	}
	
	public void sendMessage(String message) throws IOException {
		byte b[] = message.getBytes();
		out.write(b);
	}
	
	public void closeConnection() throws IOException {
		if(socket!=null) {
		socket.close();
		}
	}
	
	public static void main(String[] args) {
		try {
			Server server = new Server();
			
			server.readMessage();
			server.sendMessage("Hi I am Server");
			
			server.closeConnection();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
