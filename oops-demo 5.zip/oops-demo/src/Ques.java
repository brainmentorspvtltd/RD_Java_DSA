
public class Ques {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "3,2,6,5,1,4,8,9";
		String digits [] = str.split(",");
		String temp = "";
		boolean isConcate = false;
		int n1= 0;
		for(int i = 0; i<digits.length; i++) {
			if(digits[i].equals("5")) {
				temp +=digits[i];
				isConcate = true;
			}
			else
			if(digits[i].equals("8")) {
				temp +=digits[i];
				isConcate = false;
			}
			else
			if(isConcate) {
				temp +=digits[i];
			}
			else {
				n1 = n1 + Integer.parseInt(digits[i]);
			}
		}
		System.out.println(n1);
		System.out.println(temp);
		System.out.println(n1 + Integer.parseInt(temp));
	

	}

}
