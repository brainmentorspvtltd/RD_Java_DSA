// 1 expose
class P1{
	Layer obj = new P2(); // Upcasting
	void call() {
		obj.show();
//		obj.print();
//		obj.output();
	}
}
class P2 implements Layer, Layer2{
	private int x;
	private int y;
	@Override
	public void show() {
		System.out.println("I am P2 Show");
	}
	@Override
	public void print() {
		System.out.println("I am P2 Print...");
	}
	void output() {
		System.out.println("I am the P2 output");
	}
}
interface Layer{
	void show();
}
interface Layer2{
	void show();
	void print();
	
}
// 2 expose
class P3{
	Layer2 obj = new P2(); // Upcasting
	void call() {
		obj.show();
		obj.print();
		//obj.output();
//		obj.print();
//		obj.output();
	}
	
}
public class LoosleyCoupled {

	public static void main(String[] args) {
		P3 p3 = new P3();
		p3.call();
		
		System.out.println("*********************");
		P1 p1 = new P1();
		p1.call();
		
		// TODO Auto-generated method stub

	}

}
