import java.util.Date;

class ROISummary{
	Date date;
	double value;
	int marketRate;
}
class ImproveSummary extends ROISummary{
	String barChart;
	String pieChart;
}
class Account{
	ROISummary roi() { // Scope default - with in the package scope.
		System.out.println("2% ROI");
		return new ROISummary();
	}
	void withDraw(double amount){
		System.out.println("WithDraw "+amount);
	}
}
class FixedDepositAccount extends Account{
	// Overriding same signature but logic is different
	// Weaker Access Rule - We can increase or the same the scope during overiding
	// so default - Bigger public , protected
	// covariant rule
	@Override
	protected ImproveSummary roi() {
		System.out.println("7% ROI");
		return new ImproveSummary();
	}
	
}
class SavingAccount extends Account{
	// Overloading - same function and same logic but different argument
	void withDraw(double amount, String panCardNumber) {
		System.out.println("2 Param");
	}
}
public class OverloadingVsOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SavingAccount sa = new SavingAccount();
		sa.withDraw(555, "A22");
//		Account account = new FixedDepositAccount();
//		account.roi();
//		account.withDraw(9000);

	}

}
