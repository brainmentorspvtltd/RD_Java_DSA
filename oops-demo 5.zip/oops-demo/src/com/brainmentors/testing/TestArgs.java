package com.brainmentors.testing;

public class TestArgs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*MathOperations math = new MathOperations();
		int a = 10;
		int b= 20;
		System.out.println("Before Calling Add a "+a+" b "+b);
		int result = math.add(a, b);
		System.out.println("After Calling Add a "+a+" b "+b);
		System.out.println("Result is "+result);*/
		
		// Pass BY Ref
		Num num = new Num();
		num.input(100, 20);
		MathOperations opr = new MathOperations();
		System.out.println("Before Calling "+num.first+ " "+ num.second);
		//int result = opr.add(num);
		Result result = opr.add(num);
		System.out.println("After Calling "+num.first+ " "+ num.second);
		System.out.println(result.addResult+" "+result.mulResult + " "+result.divResult);
		
		
		
		
		
		

	}

}










