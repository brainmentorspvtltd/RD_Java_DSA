package com.brainmentors.users;
interface Calc{
	int add(int x, int y);
}
//class MyCalc implements Calc{
//
//	@Override
//	public int add(int x, int y) {
//		// TODO Auto-generated method stub
//		return x + y;
//	}
//	
//}
public class InterfaceDemo2 {

	public static void main(String[] args) {
//			MyCalc c  = new MyCalc();
//			int z = c.add(10, 20);
//			System.out.println(z);
		// 2nd Way
			Calc c = new Calc() {

				@Override
				public int add(int x, int y) {
					// TODO Auto-generated method stub
					return x + y;
				}
				// Anonymous class create
				
			};
			int result = c.add(1, 2);
			System.out.println(result);
			
			//3rd Way - Lambda Expression Java 8
			Calc c2 = (a,b)->a+b;
			result = c2.add(10, 20);
			System.out.println(result);
			
			Calc c3 = (a,b)->{
				System.out.println("A is "+a+" and b is "+b);
				return a + b;
			};
			System.out.println(c3.add(100, 200));

	}

}
