package com.brainmentors.users; // First Line 
// Class - It is like a Blue Print, Contains the Features
// Class  == Functionality

// Encapsulation  - Binding Data and Function into a Single Unit, and that unit is called class.
// Good Encapsulation - Data Members are private and Methods are public
public class Student {  // PascalCase e.g OnlineStudent, OfflineStudent
	// Data Members
	private int rollno; // Instance Variables
	private String name;
	private String course;
	private int duration;
	private String collegeName;
	private String email; // How i initalize all these fields
	private String phone;
	private String city;
	private String country;
	private String sem;
	
	/*
	 * Constructor it call when u create an object
	 * e.g new Student()
	 * It is calling a default constructor or no args or no param constructor
	 * Every class by default has default constructor
	 * class name and constructor same
	 * the default constructor by default scope is same as class.
	 * what default constructor is doing - nothing
	 * we can build our own default constructor and we can initalize the instance variables of a class
	 * So Constructor is used initalize the instance variables.
	 * Constructor return nothing 
	 * We cannot create object using new without calling a constructor.
	 * We can Param Constructor to pass the arguments
	 * So in one class we can have default as well as param both so we actually overloading the constructor
	 * Every class by default has default constructor but if u create any param constructor
	 *  so that default constructor it is killed
	 *  In constructor we initalize the primary fields
	 */
	public void Student() {
		System.out.println("I am Not Constructor , I am a Method");
	}
	private  Student() {
		name = "";
		course = "";
		collegeName  = "SRCC";
		System.out.println( "I am a Default Construcutor");
	}
	
	
	// Param Constructor
	public Student(int rollno, String name, String course, int duration) {
		// When Constructor is Calling another Constructor of same class so it use this call
		// Constructor calls always on first line. because it want to initalize first
		this(rollno, name);
		System.out.println("Calling 4 Param Constructor");
		
//		this.rollno = rollno; // Instance Var = Local var
//		this.name = name;
		this.course = course;
		this.duration = duration;
	}
	
	private Student(int rollno, String name) {
		this(); // calling default constructor, first line call
		this.rollno = rollno;
		this.name = name;
		System.out.println("Calling 2 Param Constructor");
	}
	
	// Secondary fields initalize  + to Update the fields
	// setFieldName/ setInstanceVariableName , setter void and it take arg
	public void setName(String name) {
		this.name = name;
	}
	// get - to get the value of instance variable using getter, getter e.g getInstanceVariableName 
	// getter return a value and not take any argument.
	public String getName() {
		return name; // return this.name;
	}
	
	
	// Access Modifiers 
	// private - Scope with in the class
	// default - with in the package scope
	// public - with in the package scope + outside the package scope
	
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getSem() {
		return sem;
	}
	public void setSem(String sem) {
		this.sem = sem;
	}
	public int getRollno() {
		return rollno;
	}
	// Method Members 
	// Method name or Variable Name - camelCase  e.g takeInput()
	public boolean input(int rollno , String name , String course , int duration) {
		if(rollno<=0) {
			System.out.println("RollNo Can't Be Negative or Zero");
			return false;// exit from the method
			
		}
		if(duration<=0) {
			System.out.println("Duration Can't Be Negative or Zero");
			return false;
		}
		// Instance Var = Local Var
		this.rollno  = rollno;
		//name =name; // Local Var = Local var
		this.name = name;
		this.course = course;
		this.duration = duration;
		return true;
	}
	public void print() {
		System.out.println("College Name "+collegeName);
		System.out.println("Rollno "+this.rollno);
		System.out.println("Name "+name); // this.name
		System.out.println("Course "+course); // this.course
		System.out.println("Duration "+duration); // this.duration
		System.out.println("***********************************");
	}
	
}
