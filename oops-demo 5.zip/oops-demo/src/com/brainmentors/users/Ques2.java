package com.brainmentors.users;

class A{
	int x;
	A(){
		x = 2;
		System.out.println("A Default Cons");
	}
	A(int x ){
		this();
		x = 5;
		System.out.println("A Param Cons Call");
		this.x = x + x;
	}
}
class B extends A{
	int x;
	B(){
		super(2);
		x++;
		System.out.println("B Default Cons call");
	}
	B(int x){
		super(x * x);
		this.x = x + 2;
		System.out.println("B Param cons call");
	}
	
}
class C extends B{
	int x;
	C(){
		super(3);
		x+=2;
		System.out.println("C Default Cons");
	}
	C(int x){
		this();
		this.x = this.x + x + super.x + ((A)this).x;
		System.out.println("X in C Param Cons Call "+this.x);
	}
}
public class Ques2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c = new C(100);
		

	}

}
