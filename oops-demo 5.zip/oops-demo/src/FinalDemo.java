import java.util.ArrayList;

/*
 * final it is a keyword
 * a) final - if u use with a class so class cant be inherit
 * My class is fixed or freezed so i dont any one inherit and override my methods.
 * e.g String , Math
 * b) if final use with method so that method can't be override
 * c) final use to define constants
 */
//final class Q{
// abstract and final cannot use together.
//abstract final class Q{
class Q{
	// 
	final void show() {
	System.out.println("No One Override me");	
	}
}
class T extends Q{
//	@Override
//	void show() {
//		
//	}
	void print(final int x) {
		//x++;
		//x = 10;
		System.out.println("X is "+x);
	}
}
public class FinalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// We can use final with Local Variable
		final double PI = 3.14;
		final StringBuffer sb = new StringBuffer();
		sb.append("Hi");
		sb.append("Hello");
		System.out.println(sb);
		//sb = new StringBuffer();
		final ArrayList<Integer> list  =new ArrayList<>();
		list.add(10);
		list.add(20);
		T t = new T();
		t.print(10);
		t.print(20);
		t.print(30);
		//list  = new ArrayList<>();

	}

}
