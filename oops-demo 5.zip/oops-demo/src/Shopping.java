import java.util.ArrayList;
import java.util.List;
// Has-A
class Customer{
	//List<Order> orders = new ArrayList<Order>(); // Customer has a Order
	List<Order> orders;
	Customer(){
		List<Order> list = new ArrayList<>();
		list.add(new Order());
		orders = list;
	}
//	Customer(List<Order> orders){
//		this.orders = orders;
//	}
}
class Order{
	void pay() {
		System.out.println("Pay Order");
	}
}
public class Shopping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		List<Order> list = new ArrayList<>();
//		list.add(new Order());
		//Customer customer = new Customer(list);
		Customer customer = new Customer();
		customer.orders.get(0).pay();
		customer = null;
//		System.out.println(customer);
//		System.out.println(list);
//		list.get(0).pay();
		

	}

}
