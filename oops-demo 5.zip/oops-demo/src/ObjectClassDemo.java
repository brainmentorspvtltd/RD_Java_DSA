// Object class it is a GOD Class or Root Class.
// In java we cannot create a program with out inheritance because every class parent is Object class
// Why Object class is parent of all classes.
// a) toString 
// b) equals - When we want to compare the value of the object instead of the reference.
// Object class equals internally compare the refernce so we need to override to compare our values.
// c) hashCode - 32 bit unique number
// hashCode - Pick Right Bucket - Similar Nature Objects Goes Here
// Once i am on Right Bucket so find the object in that bucket we use equals()
// Why we override toString
// We override toString to print / to get meaningful object instead of className@HexaDecimalFormHashCode
class Employee {//extends Object{
	private int id;
	private String name;
	private double salary;
	Employee(int id, String name, double salary){
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Id "+id+ " Name "+name+" Salary "+salary;
	}
	
	@Override
	public int hashCode() {
		return name.length();
	}
	
	@Override
	public boolean equals(Object object) {
		if(this == object) {
			return true;
		}
		if(object instanceof Employee) {
			// Downcasting
			Employee e = (Employee) object; 
			// value compare
			if(this.id == e.id ) {
				return true;
			}
			if(this.id == e.id && this.name.equalsIgnoreCase(e.name) && this.salary == e.salary){
				return true;
			}
		}
		return false;
	}
	
}
public class ObjectClassDemo {

	public static void main(String[] args) {
		Employee employee = new Employee(1001, "Amit",99999);
		Employee employee2 = new Employee(1001, "Amit",99999);
		Employee employee3 = new Employee(1001, "Sunil",99999);
		Employee employee4 = new Employee(1001, "Ramesh",99999);
		System.out.println(employee);
		System.out.println(employee.hashCode());
		System.out.println(employee2.hashCode());
		System.out.println(employee3.hashCode());
		System.out.println(employee4.hashCode());
		//employee.toString()
		String name = new String("Amit");
		System.out.println(name);
		System.out.println(employee == employee2); //false (Reference Compare)
		System.out.println(employee.equals(employee2)); // true if values are same.	
		System.out.println(employee.equals(employee));
	}

}
