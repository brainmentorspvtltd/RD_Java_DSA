import java.util.Arrays;
import java.util.Comparator;
import java.util.Stack;
import java.util.TreeSet;

class Compare implements Comparator<Integer>{

	@Override
	public int compare(Integer first, Integer second) {
		// TODO Auto-generated method stub
		return second - first;
	}
	
}
public class TreeSetDemo {

	public static void main(String[] args) {
		
		Stack<String> stack = new Stack<>();
		stack.push("(");
		String  y2 = stack.peek();
		String r = stack.pop();
		
		
		int x[] = {2,1,3,4,9,8,1};
		Arrays.sort(x);
		int y [] = new int[x.length];
		for(int i = 0, j=0 ; i<x.length-1; i++) {
			if(x[i]==x[i+1]) {
				continue;
			}
			y[j] = x[i];
			j++;
			System.out.println(i);
		}
		y[y.length-1] = x[x.length-1];
		System.out.println("After Removing Duplicate...");
		for(int i : y) {
			System.out.println(i);
		}
		for(int j = y.length-1; j>=0; j--) {
			System.out.println(y[j]);
		}
		//TreeSet<Integer> a  = new TreeSet<>(new Compare());
		TreeSet<Integer> a = new TreeSet<>((first, second)->second-first);
		a.add(8);
		a.add(1);
		a.add(2);
		a.add(1);
		a.add(3);
		a.add(4);
		a.add(9);
		System.out.println(a);
		

	}

}
