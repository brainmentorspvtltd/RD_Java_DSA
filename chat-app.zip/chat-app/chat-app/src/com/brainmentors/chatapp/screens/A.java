package com.brainmentors.chatapp.screens;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class A extends JFrame{
	
	public A() {
		JButton b= new JButton("Ok");
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				JOptionPane.showMessageDialog(A.this, "U Click on Ok");
				
			}
		});
		b.setBounds(10, 10, 100, 50);
		Container ct= this.getContentPane();
		ct.setLayout(null);
		ct.add(b);
		setTitle("Chat App");
		setSize(500, 500);
		setLocation(300, 200);
		setVisible(true);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = new A();

	}

}
