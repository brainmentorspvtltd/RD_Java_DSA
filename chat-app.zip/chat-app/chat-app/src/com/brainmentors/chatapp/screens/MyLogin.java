package com.brainmentors.chatapp.screens;

import java.awt.Container;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MyLogin extends JFrame {
	
	public MyLogin() {
		setSize(500, 500);
		setLocation(200, 300);
		setTitle("Chat App Project");
		JButton button = new JButton("Ok");
		Container ct = this.getContentPane();
		ct.setLayout(null);
		button.setBounds(100,200,50,50);
		ct.add(button);
		JLabel lbl= new JLabel("Counter is ");
		lbl.setFont(new Font("Arial",Font.BOLD,30));
		lbl.setBounds(100, 20, 200, 50);
		ct.add(lbl);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyLogin myLogin = new MyLogin();
		myLogin.setVisible(true);
		

	}

}
