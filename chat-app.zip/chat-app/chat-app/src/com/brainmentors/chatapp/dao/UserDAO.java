package com.brainmentors.chatapp.dao;

import com.brainmentors.chatapp.dto.UserDTO;

public class UserDAO {
	
	public String doLogin(UserDTO userDTO) {
		System.out.println(userDTO.getUserid()+" "+userDTO.getPassword());
		return null;
	}

}
