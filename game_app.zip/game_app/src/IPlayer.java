
//public interface IPlayer {
public abstract interface IPlayer{ // Interface 100% Abstract
	public static final int MAX = 100;
	int MIN = 10;
// What to do
	public abstract void jump();
	void punch();
	void kick();
}
// public abstract methods
