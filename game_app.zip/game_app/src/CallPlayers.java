
public class CallPlayers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ken ken =new Ken();
		ken.jump();
		ken.kick();
		ken.punch();

	}

}
