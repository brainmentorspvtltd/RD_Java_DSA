

public class Ken implements IPlayer {

	@Override
	public void jump() {
		// TODO Auto-generated method stub
		System.out.println("Ken Jump "+MAX);
		
	}

	@Override
	public void punch() {
		System.out.println("Punch High");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void kick() {
		System.out.println("Kick Low");
		// TODO Auto-generated method stub
		
	}

}
