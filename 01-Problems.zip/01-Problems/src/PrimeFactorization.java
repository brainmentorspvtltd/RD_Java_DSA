import java.util.Scanner;

public class PrimeFactorization {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a number : ");
		int n = scanner.nextInt();
		
		for(int i = 2; i * i <= n; i++) {
			while(n % i == 0 ) {
				n = n / i;
				System.out.print(i + " ");
			}
		}
		if(n != 1) {
			System.out.println(n);
		}

	}

}
