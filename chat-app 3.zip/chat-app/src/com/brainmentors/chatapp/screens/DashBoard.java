package com.brainmentors.chatapp.screens;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;

public class DashBoard extends JFrame {

	
	public static void main(String[] args) {
		
					DashBoard window = new DashBoard();
					window.setVisible(true);
				
	}

	/**
	 * Create the application.
	 */
	public DashBoard() {
		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setExtendedState(MAXIMIZED_BOTH);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(DashBoard.class.getResource("/com/brainmentors/chatapp/screens/sta-je-chat.jpeg")));
		getContentPane().add(lblNewLabel, BorderLayout.CENTER);
		
	}

}
