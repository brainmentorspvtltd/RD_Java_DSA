package com.brainmentors.chatapp.network;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	ServerSocket serverSocket ;
	public Server() throws IOException {
		serverSocket = new ServerSocket(9001);
		System.out.println("waiting for the Client....");
		while(true) {
		Socket socket = serverSocket.accept(); // HandShaking
		}
	}
	
	public static void main(String[] args) {
		
	}

}
