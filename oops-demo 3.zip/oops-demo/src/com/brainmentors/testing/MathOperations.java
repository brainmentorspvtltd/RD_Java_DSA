package com.brainmentors.testing;
class Result{
	int addResult;
	int mulResult;
	int divResult;
}
public class MathOperations {
	// This function is taking Primitive as an argument return a primitive
public int add(int x, int y) {
	x = x +10;
	y = y + 20;
	System.out.println("X is "+x+" Y is "+y);
	return x + y;
}

public Result add(Num num) {
	num.first = num.first + 10;
	num.second = num.second + 20;
	System.out.println("Inside Add Changes "+num.first + " "+num.second);
	//return num.first + num.second;
	Result result = new Result();
	result.addResult = num.first  + num.second;
	result.mulResult = num.first * num.second;
	result.divResult = num.first / num.second;
	return result;
}
}
