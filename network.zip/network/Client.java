package com.brainmentors.chatapp.network;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;



public class Client {
	Socket socket ;
	OutputStream out;
	InputStream in;
	ClientThread clientThread;
	public Client() throws UnknownHostException, IOException{
		System.out.println("Client Comes");
		socket = new Socket("localhost",9001); // Client Socket - Connect to the Server
		in = socket.getInputStream();
		out = socket.getOutputStream();
		clientThread= new ClientThread(in); // Custom read thread
		clientThread.start();
		
		
		
	}
	public void sendMessage(String message) throws IOException {
		byte b[] = message.getBytes();
		out.write(b);
	}
	public void closeConnection() throws IOException {
		if(socket!=null) {
		socket.close();
		}
	}
	// Main Thread Write
	public static void main(String[] args) {
		try {
			Client client= new Client();
			while(true) {
			System.out.println("Send Message to Server");
			String message = new Scanner(System.in).nextLine();
			client.sendMessage(message+"\n");
			}
			//client.closeConnection();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
