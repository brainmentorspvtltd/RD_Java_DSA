package com.brainmentors.chatapp.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;



public class Server {
	ServerSocket serverSocket ;
	Socket socket ;
	InputStream in;
	OutputStream out;
	ArrayList<ServerThread> sockets = new ArrayList<>();
	
	public Server() throws IOException {
		serverSocket = new ServerSocket(9001); // Server ready 
//		in = socket.getInputStream();
//		out = socket.getOutputStream();
		System.out.println("waiting for the Client....");
		while(true) {
		socket = serverSocket.accept();  // New Socket Create
		ServerThread serverThread = new ServerThread(this, socket);
		sockets.add(serverThread);
		serverThread.start();
		
		System.out.println("Client Joins");
		}
		//socket.close();
		
	}
//	public void readMessage() throws IOException {
//		BufferedReader br = new BufferedReader(new InputStreamReader(in));
//		String inputLine = "";
//		while(true) { // Infinite Loop (Main Thread Busy)
//			inputLine = br.readLine();
//			System.out.println("Message Rec "+inputLine);
//		}
//		 
//	}
//	
//	public void sendMessage(String message) throws IOException {
//		byte b[] = message.getBytes();
//		out.write(b);
//	}
//	
//	public void closeConnection() throws IOException {
//		if(socket!=null) {
//		socket.close();
//		}
//	}
	
	public static void main(String[] args) {
		try {
			Server server = new Server();
			
//			server.readMessage();
//			server.sendMessage("Hi I am Server");
//			
//			server.closeConnection();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
