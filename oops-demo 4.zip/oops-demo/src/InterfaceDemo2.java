
interface I1{
	int X = 10; // public static final int X = 10;
	void show(); // public abstract void show();
	public default void print() {
		System.out.println("I am I1 Print");
	}
}

interface I2{ 
	int X = 20; // public static final int X = 20;
	void show(); // public abstract void show();
	public default void print() {
		System.out.println("I am I2 Print");
	}
}
// Interface can inherit another interface 
// Interface can do multiple inheritance
interface I3 extends I1, I2{
	@Override
	public default void print() {
		I1.super.print();
		I2.super.print();
		System.out.println("I3 Print...");
	}
}
class I4 implements I3{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
	
}
public class InterfaceDemo2 {

	public static void main(String[] args) {
			I4 obj = new I4();
			obj.print();

	}

}
