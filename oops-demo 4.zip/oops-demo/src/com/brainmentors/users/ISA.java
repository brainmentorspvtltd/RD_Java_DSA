package com.brainmentors.users;
abstract class Customer{
	int id;
	String name;
	double balance;
	Customer(){
		name = "";
		System.out.println("Customer class Cons Call Default ");
	}
	Customer(int id , String name, double balance){
		this.id = id;
		this.name= name;
		this.balance = balance;
		System.out.println("Customer Class Param Cons Call");
	}
	// abstract class may have abstract methods
	// if any method is abstract so class must be abstract
	abstract double getBalance(); // Body less --> All Child need to override this, otherwise child become abstract
	void print() {
		System.out.println("Id "+id);
		System.out.println("Name "+name);
		System.out.println("Balance "+balance);
	}
}
class CashCustomer extends Customer{
	double discount;
	CashCustomer(){
		// Implicit super call
				// super(); // using super constructor it is calling parent class constructor
				//and it is also a Constructor Chaining, by default child constructor is call parent class default constructor
		discount = 5.2;
		System.out.println("CashCustomer class Cons Call Default ");
	}
	CashCustomer(double discount,int id , String name, double balance){
		// Implicit super call super() ; parent default cons call
		super(id, name,balance); // first line call
		this.discount = discount;
		System.out.println("CashCustomer Class Param Cons Call");
	}
	@Override
	double getBalance() {
		return 1000;
	}
	// Override the parent print function
	@Override // We Put the Annotation - Annotation give the special meaning to the compiler, in this case
	// we are doing overriding
	/*
	 * When parent function is seems outdated so we override the parent function in child class with the same signature
	 * signature means return type function name (args) must be same.
	 * If we use @Override Annotation and we do wrong overriding it means wrong signature write so it will give the 
	 * compile time error
	 * Overriding hide the parent class function so only childclass function is visible
	 */
	void print() {
		super.print(); // so we are calling parent class print
		System.out.println("Discount "+discount);
	}
}
class CreditCustomer extends Customer{
	int limit;
	double roi;
	CreditCustomer(){
		// Implicit super call
		// super(); // using super constructor it is calling parent class constructor
		//and it is also a Constructor Chaining, by default child constructor is call parent class default constructor
		limit = 100000;
		roi = 7.2;
		System.out.println("CreditCustomer class Cons Call Default ");
	}
	CreditCustomer(int limit , int roi, int id , String name, double balance){
		// Implicit super call super() ; parent default cons call
		// Explicit super cons call
		super(id, name, balance);
		this.limit = limit;
		this.roi  = roi;
		System.out.println("CreditCustomer Class Param Cons Call");
	}
	@Override
	double getBalance() {
		return 1000 * roi;
	}
}
public class ISA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//CashCustomer cashCustomer = new CashCustomer();
		//CreditCustomer creditCustomer = new CreditCustomer();
		//Customer customer = new Customer();
		Customer customer = new CashCustomer(); // Upcasting , Object create CashCustomer
		CashCustomer cashCustomer = new CashCustomer(10.0, 10, "Amit",9999);
		cashCustomer.print();
		System.out.println(cashCustomer.getBalance());
		
		//cashCustomer.printIt();

	}

}
