package com.brainmentors.users;
/*
 * static is a keyword
 * static things will load when class is loaded in memory
 * static things bind with class so it call with classname there is no need to create an object for static things
 * so first class is loaded then class is executed
 */
/*
 * final vs static 
 * final - fix cannot be change , final can be local variable
 * static - can be change , main thing - it is loaded when class is loaded so it comes early in the memory and gone late in the memory.
 	when class is loaded it comes and when class is unloaded then gone.
 */
class User{
	String name;
	String password;
	static int count;
	User(String name, String password){
		this.name  = name;
		this.password = password;
		count++;
		System.out.println("User Count "+count);
	}
}
class Validation{
	private Validation() {}
	static boolean isValidPhoneNumber(String phoneNumber) {
		if(phoneNumber== null) {
			return false;
		}
		if(phoneNumber.length()==0) {
			return false;
		}
		if(phoneNumber.length()!=10) {
			return false;
		}
		return true;
	}
}
class A1{
	int x ; // Instance Variable
	static int y;
	A1(){
		x = 100;
		System.out.println("Instance Var Initalize in Constructor");
	}
	static {
		y = 100; 
		System.out.println("I call when class is loaded and u can initalize the static things here");
	}
	static {
		System.out.println(" I Call Next After the Above One");
	}
	{
		System.out.println("I am a Init Block...."); // Instance Var , Before Cons
	}
}
public class StaticDemo {

	public static void main(String[] args) {
		//System s = new System();
		//Math m = new Math();
		//System.out.println(A1.y);
		A1 obj = new A1();
		Math.pow(2, 4);
		//Validation validation = new Validation();
		System.out.println(Validation.isValidPhoneNumber("22222")?"Valid":"Not Valid");
		User user = new User("amit","1111");
		User ram = new User("ram","13111");
		User ramesh = new User("ramesh","2111");
		

	}

}
