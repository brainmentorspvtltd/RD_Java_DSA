package com.brainmentors.users;
class Foo{
	int x;
	Foo(){ x= 1; System.out.println("Foo Default Cons Call");}
	// if u create param so default is killed
	Foo(int x){ this();  x = 2; System.out.println("Foo Param Cons Call");}
}
class Bar extends Foo{
	int y; 
Bar(){ super(1); y  = 2 * x; System.out.println("Bar Default Cons Call");}
Bar(int y){
	this(); // own class default cons call
	this.y = y * x;
	//super(10); // Explicit Call
	// super(); // Implicit Call (Parent Default Cons)
	System.out.println("Bar Param Cons Call");}
}
public class Ques {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bar bar = new Bar(10);
		System.out.println(bar.y + " "+bar.x);

	}

}
