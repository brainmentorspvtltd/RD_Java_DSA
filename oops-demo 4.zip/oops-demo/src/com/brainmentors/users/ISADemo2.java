package com.brainmentors.users;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

class P{
	void show() {
		System.out.println("P Show");
	}
	void disp() {
		System.out.println("P Disp");
	}
	void output() {
		System.out.println("P Output");
	}
}
class C1 extends P{
	void print() {
		System.out.println("C Print..");
	}
	/*
	 * Overriding - When there is Inheritance
	 * Method Signature must be same.
	 */
	@Override
	void show() {
		System.out.println("I am SHow in C1 Class");
	}
}
class C2 extends P{
	void myoutput() {
		System.out.println("I am the C2 Output Function...");
	}
}
class Caller {
	// Upcasting
	// Polymorphic/Generic Function
	void call(P p) {
		// Calling Common thing
		p.show(); // Call C1 Show method becuase it is override
		p.disp();
		p.output();
		if(p instanceof C1) {
			C1  c = (C1) p ; // Downcasting
			c.print();
		}
		else
			if(p instanceof C2) {
				C2 c = (C2) p; // Downcasting
				c.myoutput();
			}
		System.out.println("*******************************");
	}
}
public class ISADemo2 {
	static void printList(List<Integer> list) {
		System.out.println(list);
	}
	public static void main(String[] args) {
		ArrayList<Integer> l = new ArrayList<>();
		printList(l);
		printList(new Vector<>());
		printList(new LinkedList<>());
		List<Integer> list = new ArrayList<>(); // Upcasting
		list = new Vector<>(); // Upcasting
		list = new LinkedList<>(); // Upcasting
//		Vector<Integer>
//		ArrayList<Integer> list = new ArrayList<>(); 
//		list.add(10);
//		list.add(0, 100);
		
		Caller obj = new Caller();
		obj.call(new C1());
		obj.call(new C2());
		// TODO Auto-generated method stub
		// Code Reuse
//		P c = new C1(); // Upcasting - Object u created of child but u casted into parent
//		// So Now u can access only those features which is avaliable from parent
//		//C1 c = new C1(); // Create Child Object
//		c.show(); // Call C1 Show method becuase it is override
//		c.disp();
//		c.output();
//		//c.print();
//		
//		 c = new C2(); // UPcasting
//		//C2 c2=new C2();
//		c.show();
//		c.disp();
//		c.output();
		//c.myoutput();

	}

}
