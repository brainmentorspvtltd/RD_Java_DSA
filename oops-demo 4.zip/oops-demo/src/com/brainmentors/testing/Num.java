package com.brainmentors.testing;

 class Num{
	int first;
	int second;
	void input(int first, int second) {
		this.first = first;
		this.second = second;
	}
}