package com.brainmentors.testing;

import com.brainmentors.users.Student;

public class TestStudent {
	public static void main(String[] args) {
		Student ram; // ram is a variable, ram type is Student, Student is a Custom Type
		ram = new Student(101, "Ram","Java",90);
		ram.setCourse("Advance Java");
		//ram = new Student();
		ram.print();
		ram.setPhone("2222");
		System.out.println("Phone "+ram.getPhone());
		//ram.Student(); // Call like a Method
		//ram.rollno = -1001;
		//ram.duration= -100;
		
		// Abstraction - Showing the Essential Things (public) and Hiding those things (Private)
//		if(ram.input(-1001, "Ram", "Java", 90)) {
//		ram.print();
//		}
//		else {
//			System.out.println("No Ouput For INvalid Data...");
//		}
//		System.out.println(ram.rollno);
//		System.out.println(ram.name);
//		System.out.println(ram.course);
//		System.out.println(ram.duration);
		
		//ram.print();
//		System.out.println(ram.rollno);
//		System.out.println(ram.name);
//		System.out.println(ram.course);
//		System.out.println(ram.duration);
//		Student shyam = new Student(); 
//		shyam.input(1002, "Shyam", "Advance Java", 90);
////		shyam.rollno = 1002;
////		shyam.name = "Shyam";
//		shyam.print();
//		int x; // x is a variable, x type int
//		x = 10; // initalize the x
	}
}
