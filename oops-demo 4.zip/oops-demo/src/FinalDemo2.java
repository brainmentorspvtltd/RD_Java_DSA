class B1{
	final int x; // Instance Variable
	B1(){
		x = 10;
	}
	B1(int x){
		//this();
		this.x = x;
	}
//	void takeInput() {
//		x =20;
//	}
}
public class FinalDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
