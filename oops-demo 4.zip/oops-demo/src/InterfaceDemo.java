//abstract interface DB {
interface DB{
	// Interface = Constants + Abstract methods
	// Interface no constructor - because interface is 100 % Abstract , abstract things object u can't create
	// static (Eager) Class Bind + final (Fix)
	int MAX = 100; // public static final int MAX = 100;
	boolean create(); // public abstract boolean create()
	void print(); // public abstract void print()
	
	// From Java 8 onwards we can define method body in interface
	public default void openConnection() {
		System.out.println("DB Connection Open");
	}
	default void closeConnection() {
		System.out.println("DB Connection Close");
	}
	// Java 8 Onwards we can define static method in interface
	static void show() {
		System.out.println("I am DB Show Method");
	}
}
interface Secure{
	boolean encryption();
}
/* interface - What to do
 * class - How to do
 * interface is 100% Abstract method
 * interface are used to define standard or prototype
 * In our case we define interface which contain CRUD Operations (Abstract)
 */
// Class implement an interface (All the abstract method need to be override.
// A one class can implement N Number of interfaces
//class <ClassName> extends <ParentClassName> implements <InterfaceName>, <InterfaceName> .....N
class Oracle implements DB, Secure{

	@Override
	public boolean create() {
		// TODO Auto-generated method stub
		System.out.println("Oracle Record Create Logic");
		return true;
	}

	@Override
	public void print() {
		System.out.println("Oracle Record Print Logic");
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean encryption() {
		// TODO Auto-generated method stub
		System.out.println("Encryption Logic SHA1 Start....");
		return false;
	}
	
}
class MySql implements DB{

	@Override
	public boolean create() {
		// TODO Auto-generated method stub
		System.out.println("MY SQL Create");
		return false;
	}

	@Override
	public void print() {
		System.out.println("My SQL Print");
		// TODO Auto-generated method stub
		
	}
	
}
public class InterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DB.show();
		Oracle oracle = new Oracle();
		oracle.create();
		oracle.print();
		oracle.openConnection();
		
		oracle.encryption();
		oracle.closeConnection();
		
		MySql mysql = new MySql();
		mysql.create();
		mysql.print();
	}

}
