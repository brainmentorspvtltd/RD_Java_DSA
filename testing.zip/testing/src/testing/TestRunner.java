package testing;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunner {

	public static void main(String[] args) {
		Result result = JUnitCore.runClasses(ShoppingTestSuite.class);
		for(Failure failure : result.getFailures()) {
			System.out.println("Test Fail ::: "+failure);
		}
		System.out.println("Total Run Count "+result.getRunCount());
		int ignoreCount = result.getIgnoreCount();
		boolean r = result.wasSuccessful();
		System.out.println("Total Pass Count "+(result.getRunCount() - result.getFailureCount()));

	}

}
