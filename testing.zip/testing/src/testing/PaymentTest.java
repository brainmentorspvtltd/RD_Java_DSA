package testing;

import org.junit.Assert;
import org.junit.Test;

public class PaymentTest {
	@Test
	public void testPay() {
		Assert.assertTrue(10==10);
	}

}
