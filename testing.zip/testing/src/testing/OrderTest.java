package testing;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import logic.Order;

public class OrderTest {
	
	static Order order;
	@BeforeClass
	public static void start() {
		order = new Order();
		System.out.println("I am in Before");
	}
	
	@Before
	public void beforeTC() {
		System.out.println("Before TC");
	}
	
	@After
	public void afterTC() {
		System.out.println("After TC");
	}
	
	// Testcases
	@Test(timeout = 1000)
	public void testBookOrder() {
		//Order order =new Order();
		int orderId  = order.bookOrder();
		Assert.assertTrue(orderId>0);
		
	}
	//@Ignore
	@Test(expected = NullPointerException.class)  // Negative
	// @Test
	public void testOrderCount() {
		//Order order =new Order();
		int count = order.getOrders();
		Assert.assertEquals(10, count);
	}
	
	@AfterClass
	public static void end() {
		order = null;
		System.out.println("I am in After");
	}
}
