package logic;

public class Order {
		public int bookOrder() {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return 1;
		}
		public int getOrders() {
			if(10>2) {
			throw new NullPointerException();
			}
			return 10;
		}
}
