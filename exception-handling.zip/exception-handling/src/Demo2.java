import java.io.FileInputStream;
import java.util.InputMismatchException;
import java.util.Scanner;
// Checked Exception
//class NegativeNumberException extends Exception{}

// Unchecked Exception
// User Define Exception or Custom Exception  or Business Exception
class NegativeNumberException extends Exception{
//class NegativeNumberException extends RuntimeException{
	private String msg;
	NegativeNumberException(String msg){
		super(msg);
		this.msg = msg;
	}
}

public class Demo2 {
	private static Scanner scanner= new Scanner(System.in);
	private static int firstNumber;
	private static int secondNumber;
	private static int result;
	// throws - not handling the exception by own , pass it to the caller
	static void takeFirst() throws NegativeNumberException { // method level - throws A, B, C
		try {
		System.out.println("Enter the First Number");
		 firstNumber  =  scanner.nextInt();
		 if(firstNumber<0) {
			 // statement level
			 throw new NegativeNumberException("Number is Negative u can't do any calculation"); // Explicit throw Custom Exception
		 }
		}
		catch(InputMismatchException ex) {
			System.out.println("Invalid Number only enter 0 to 9");
			scanner.nextLine();
			takeFirst();
		}
	}
	static void takeSecond() {
		try {
		System.out.println("Enter the Second Number");
		 secondNumber  =  scanner.nextInt();
		}
		catch(InputMismatchException ex) {
			System.out.println("Invalid Number only enter 0 to 9");
			scanner.nextLine();
			takeSecond();
		}
	}
	static void divide() {
		try {
			
		 result = firstNumber/ secondNumber; // throw new ArithmeticException(); // Implicit throw
		}
		catch(ArithmeticException ex) {
			System.out.println("U Divide a Number with Zero ");
			takeSecond();
			divide();
		}
	}
	static void print() {
		System.out.println("Result "+result);
	}
	static void caller() throws NegativeNumberException {
		try {
			takeFirst();
			takeSecond();
			divide();
			print();
			//return; // exit from the function but run finally then exit
			//throw new Exception(); // Explicit throw
			System.exit(0);
			}
			catch(ArithmeticException | InputMismatchException ex) {
				System.out.println("Arithmetic or InputMisMatch Exception ");
				
			}
			finally {
				// resource clean up (db connection close, network socket close, file close)
				// always execute block, either exception comes or not
				scanner.close();
				System.out.println("Scanner Close");
			}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Throw Early Catch Later
		try {
			caller();
		} catch (NegativeNumberException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage()); // what is the exception
			e.printStackTrace(); // Where is the Exception
		}
		// windows c:\\users\\amit
		//String path = "/Users/amitsrivastava/Documents/java-codes-learn/exception-handling/src/Demo1.java";
		//FileInputStream fs = new FileInputStream(path);
		
		
		

	}

}
