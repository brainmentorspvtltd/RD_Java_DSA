import java.util.InputMismatchException;
import java.util.Scanner;

public class Demo1 {
/*
 * Thread - Code in Execution is called Thread
 * main is a Thread 
 * Per thread per stack
 * main call scanner.nextInt() --> next() 
 * Exception - Stack Trace
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		try { // Guarded Region
		System.out.println("Enter the First Number");
		int firstNumber = scanner.nextInt();
		//String e = null;
		//e.length();
		System.out.println("Enter the Second Number");
		int secondNumber = scanner.nextInt();
		int result = firstNumber/ secondNumber;
		System.out.println(result);
		scanner.close();
		}
		
		catch(InputMismatchException ex) {
			// Treatment
			System.out.println("Enter Digit b/w 0 to 9 ");
		}
		catch(ArithmeticException ex) {
			System.out.println("U divide a number with zero");
		}
		catch(Exception ex) {
			System.out.println("Mis Exception ");
		}
		
		

	}

}
