
public class CommaDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String qq = "10,20,30,40,50";
		String numbers [] = qq.split(",");
		for(String n :numbers) {
			System.out.println(n);
		}

	}

}
