import java.util.ArrayList;
import java.util.Collections;

final class A{
	
}
class B {
	final double PI = 3.14;
	final void show() {
		
	}
}
class Human{
	Human(){
		System.out.println("Born");
	}
	@Override
	protected void finalize() {
		System.out.println("Good Bye...");
	}
}
public class FinalVsFinalizeVsFinally {

	public static void main(String[] args) {
		
		ArrayList<Integer> l2 = new ArrayList<>();
		ArrayList<Integer> l3 = new ArrayList<>();
		ArrayList<ArrayList<Integer>> l1 = new ArrayList<>();
		l2.add(10);
		l2.add(2);
		l2.add(5);
		l2.add(4);
		l3.add(100);
		l3.add(90);
		l1.add(l2);
		l1.add(l3);
		System.out.println("Before "+l1);
		for(ArrayList<Integer> i : l1) {
			i.sort((a,b)->a-b);
		}
		System.out.println("After "+l1);
		
		
		Human human = new Human();
		human = null;
		System.gc(); // request to gc
		for(int i = 1;i<=10; i++) {
			System.out.println("I is "+i);
		}
		
		// TODO Auto-generated method stub
		/*
		 * final - FIX
		 * 1. with class - Can't be inherit
		 * 2. with method - can't be override
		 * 3. with Constant - Can't be change
		 */
		/*
		 * try with finally (throws)
		 * try catch finally
		 * finally - always execute
		 */
		/*
		 * finalize - like a destructor block- when object goes from the memory this will be called.
		 */

	}

}
