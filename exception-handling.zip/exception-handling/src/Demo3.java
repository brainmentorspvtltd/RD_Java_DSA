import java.util.InputMismatchException;

public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// try with multiple catch block
//		try {
//			int e = 100/2;
//			int arr[] = new int[10];
//			arr[11] = 11;
//			
//		}
//		catch(ArithmeticException ex) {
//			System.out.println("Divide by Zero "+ex);
//		}
//		catch(ArrayIndexOutOfBoundsException ex) {
//			System.out.println("Out of Range");
//		}
		
		// Nested try blocks
		try {
		try {
			int e = 100/2;
		} // inner
		catch(ArithmeticException ex) {
			System.out.println("Divide by Zero "+ex);
		} // inner catch
			int arr[] = new int[10];
			arr[11] = 11;
			
		} // outer
		
		catch(ArrayIndexOutOfBoundsException ex) {
			System.out.println("Out of Range");
		} // outer catch
		
		
		// try , catch Inside try
		try {
			
		}
		catch(ArithmeticException ex) {
			try {
				
			}
			catch(InputMismatchException ex1) {
				
			}
		}

	}

}
