package com.brainmentors.shopping.payments;

public class Payment {

}
