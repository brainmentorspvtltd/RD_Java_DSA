package com.brainmentors.shopping.users;

import com.brainmentors.shopping.orders.Order;

public class Customer {
	Order order = new Order(); // Has a RelationShip
	
	public void confirmOrder(){
		order.bookOrder();
	}

}
