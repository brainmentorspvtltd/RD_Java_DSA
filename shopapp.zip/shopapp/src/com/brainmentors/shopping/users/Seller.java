package com.brainmentors.shopping.users;

public class Seller {

}
