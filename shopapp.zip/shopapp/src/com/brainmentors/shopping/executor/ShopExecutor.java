package com.brainmentors.shopping.executor;

import com.brainmentors.shopping.users.Customer;

public class ShopExecutor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer = new Customer();
		customer.confirmOrder();

	}

}
