package com.brainmentors.shopping.orders;

public class Order {
	public void bookOrder() {
		System.out.println("Book Order");
	}
}
