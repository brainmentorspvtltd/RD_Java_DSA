package com.brainmentors.users; // First Line 
// Class - It is like a Blue Print, Contains the Features
// Class  == Functionality

// Encapsulation  - Binding Data and Function into a Single Unit, and that unit is called class.
// Good Encapsulation - Data Members are private and Methods are public
public class Student {  // PascalCase e.g OnlineStudent, OfflineStudent
	// Data Members
	private int rollno; // Instance Variables
	private String name;
	private String course;
	private int duration;
	
	// Access Modifiers 
	// private - Scope with in the class
	// default - with in the package scope
	// public - with in the package scope + outside the package scope
	
	// Method Members 
	// Method name or Variable Name - camelCase  e.g takeInput()
	public boolean input(int rollno , String name , String course , int duration) {
		if(rollno<=0) {
			System.out.println("RollNo Can't Be Negative or Zero");
			return false;// exit from the method
			
		}
		if(duration<=0) {
			System.out.println("Duration Can't Be Negative or Zero");
			return false;
		}
		// Instance Var = Local Var
		this.rollno  = rollno;
		//name =name; // Local Var = Local var
		this.name = name;
		this.course = course;
		this.duration = duration;
		return true;
	}
	public void print() {
		System.out.println(this.rollno);
		System.out.println(name); // this.name
		System.out.println(course); // this.course
		System.out.println(duration); // this.duration
		System.out.println("***********************************");
	}
	
}
