package codes; // It always a first statement in Java Prg

// Comments in Java

// Single Line Comment

/*
 * This class i create to learn about comments
 * Single Line Comment or Multi Comment
 */
/**
 * This is For the documentation Purpose 
 * @author amitsrivastava
 * @since Jan 22
 * @version 1.0
 */
public class FirstClass {

	public static void main(String[] args) {
		double price = 9000.20; // Store the Product Price

	}

}
