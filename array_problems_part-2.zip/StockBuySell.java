
public class StockBuySell {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int prices[] = {7,1,5,3,6,4};
		// prefixMin = [7,1,1,1,1,1];
		int n = prices.length;
		int profit = 0;

//		int prefixMin[] = new int[n];
//		prefixMin[0] = prices[0];
//		for(int i = 1; i < n; i++) {
//			prefixMin[i] = Math.min(prefixMin[i - 1], prices[i]);
//		}
//		
		int finalProfit = 0;
//		for(int i = 1; i < n; i++) {
//			finalProfit = prices[i] - prefixMin[i - 1];
//			profit = Math.max(finalProfit, profit);
//		}
		
		int minPrice = prices[0];
		for(int i = 1; i < n; i++) {
			finalProfit = prices[i] - minPrice;
			profit = Math.max(finalProfit, profit);
			minPrice = Math.min(minPrice, prices[i]);
		}
		
		System.out.println("Total Profit :: " + profit);

	}

}
