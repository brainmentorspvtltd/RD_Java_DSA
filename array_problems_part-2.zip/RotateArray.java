
public class RotateArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {1,5,2,4,3};
		int n = arr.length;
		int k = 3;
		int temp[] = new int[n];
		for(int i = 0; i < n; i++) {
			temp[((i + k) % n)] = arr[i];
		}
		
		System.out.println("After Rotation...");
		for(int i : temp) {
			System.out.print(i + ",");
		}
	}

}
