public class RotateArrayApproach_1 {
    public static void main(String[] args) {
        int arr[] = {5,0,1,4,2};
        int k = 3;

        for(int j = 1; j <= k; j++) {
            int lastElement = arr[arr.length - 1];
            for(int i = arr.length - 2; i >= 0; i--) {
                arr[i+1] = arr[i];
            }
            arr[0] = lastElement;
        }
        System.out.println("After Rotation...");
        for(int i : arr) {
            System.out.print(i+", ");
        }
    }
}
