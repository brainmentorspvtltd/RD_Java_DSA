package com.brainmentors.consume;

import com.brainmentors.produce.IProducer;
import com.brainmentors.produce.Producer;
import com.brainmentors.utils.Factory;

public class Consume2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Producer p = new Producer();
//		p.show();
//		p.disp();
//		p.notExposed();
		
//		IProducer p = new Producer(); // Upcasting
//		p.show();
//		p.disp();
		
		IProducer p = Factory.getInstance();
		p.show();
		p.disp();
	}

}
