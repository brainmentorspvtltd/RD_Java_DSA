package com.brainmentors.utils;

import java.util.ResourceBundle;

import com.brainmentors.produce.IProducer;
import com.brainmentors.produce.Producer;

public interface Factory {
	public static IProducer getInstance() {
//		IProducer producer = new Producer(); // Upcasting
//		return producer;
		IProducer object = null;
		// Read Property file
		ResourceBundle rb = ResourceBundle.getBundle("config");
		// read a key
		String fullClassName = rb.getString("classname");
		try {
			 object = (IProducer)Class.forName(fullClassName).getDeclaredConstructor().newInstance();
		}
		catch(Exception ex) {
			System.out.println("Exception During Object creation");
			ex.printStackTrace();
		}
		return object;
	}
}
