package com.brainmentors.produce;

public class Producer implements IProducer {
	@Override
	public void show() {
		notExposed(10,2);
		System.out.println("I am the Show");
	}
	@Override
	public void disp() {
		notExposed(10,3);
		System.out.println("I am the Disp");
	}
	public void notExposed(int x, int y) {
		System.out.println("I am Not Exposed.."+ (x*y));
	}
}
