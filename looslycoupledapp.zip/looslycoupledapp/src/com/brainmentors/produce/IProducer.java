package com.brainmentors.produce;

public interface IProducer {
	// These are exposed to the consumer
	public void show();
	public void disp();
}
