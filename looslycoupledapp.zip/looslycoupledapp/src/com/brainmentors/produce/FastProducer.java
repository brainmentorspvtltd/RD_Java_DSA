package com.brainmentors.produce;

public class FastProducer implements IProducer{

	@Override
	public void show() {
		System.out.println("I am the Fast Show");
		iamNotExposed();
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disp() {
		System.out.println("I am the Fast Disp");
		iamNotExposed();
		// TODO Auto-generated method stub
		
	}
	
	public void iamNotExposed() {
		System.out.println("I am Not exposed");
	}

}
