import java.util.Scanner;

public class Input {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
    //     Scanner s = new Scanner("Hello How are You\n I am Fine\n");
    //     int counter = 0;
    //    // while(s.hasNext()){
    //        while(s.hasNextLine()){
    //         counter++;
    //         String line = s.nextLine(); // current line and move to next line
    //         //String word = s.next(); // current word and move to next word
    //     }

        //System.out.println(counter);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Name");
        String name = scanner.next();
        System.out.println("Enter the Age");
        int age = scanner.nextInt();
        System.out.println(name +" "+age);
        scanner.close();
        s.close();
    }
}
