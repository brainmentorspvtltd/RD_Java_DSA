import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Input3 {
    public static void main(String[] args) throws Exception  {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the Id");
        int id = Integer.parseInt(br.readLine());
        System.out.println("Enter the Name");
        String name = br.readLine();
        System.out.println(name + " "+id);
        br.close();
    }
}
