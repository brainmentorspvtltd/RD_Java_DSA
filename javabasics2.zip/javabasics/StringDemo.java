public class StringDemo {
    public static void main(String[] args) {
        Integer w = 100; // Integer Literal
        String name = "Amit"; // String Literal
        String name2 = "Amit";
        String name3 = new String("Amit").intern();
        System.out.println(name==name2); // true
        System.out.println(name == name3); // true
        //StringBuilder sb2= new StringBuilder("Amit");
        StringBuffer sb2 = new StringBuffer("Amit"); //4 + 16 = 20
        System.out.println(sb2.length()); //4
        System.out.println(sb2.capacity()); //20
        sb2.append("ghdfjghdfjghfjkhgfdhgjhdfjkghdfhkghfdjk");
        System.out.println(sb2.length()); //?
        System.out.println(sb2.capacity()); //?
        sb2.append("ee");
        System.out.println(sb2.length()); //?
        System.out.println(sb2.capacity()); //?

        StringBuffer sql = new StringBuffer("select * from product");
        double price = 9000;
        if(price>0){
            sql = sql .append( " where price>=").append(price);
        }

    }
}
