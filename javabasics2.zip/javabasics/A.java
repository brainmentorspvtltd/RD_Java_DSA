public strictfp class A {
    public static  void main(String[] args) {
        float a = 190.9f;
        float b = 66.8f;
        double c = a /b;
        char w = 'A';
        System.out.println(w);


    }
}
