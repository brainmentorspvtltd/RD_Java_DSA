import java.util.Scanner;

public class Input2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       System.out.println("Enter the Id");
       int id  =  scanner.nextInt();
       System.out.println("Enter the Name");
       scanner.nextLine(); // eat \n
       String name = scanner.nextLine();
       System.out.println(id + " "+name);
       scanner.close();
    }
}
