public class Loops {
    public static void main(String[] args) {
        outer:
        for(int i = 1; i<=3; i++){
            //abcd:
            for(int j = 1; j<=3; j++){
                if(i==j){
                    continue outer;
                   // break outer;
                    //break; // exit from the current loop
                    //continue; // skip the current iteration
                }
                System.out.println("I "+i+" J  "+j);
            }
        }
        // int k = 1000;
        // do{
        //     System.out.println(); // Menu Driven (ATM + Hotel)
        // }while(k<=10);
        // int i =1;
        // while(i<=10){
        //     System.out.println(i);
        //     if(i%2==0){
        //     i++;
        //     }
        //     else{
        //         i+=2;
        //     }
        // }
        // for(int j = 1; j<=10; j++){
        //     System.out.println(j);
        // }
    }
}
