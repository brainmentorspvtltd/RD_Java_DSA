class V{

}
public class MyMain {
    // N number add
    static public  void main(String ...arr) {
        int total = 0;
        if(arr.length==0){
            System.out.println(total);
        }
        else{
            for(int i = 0; i<arr.length; i++){
                try{
                total += Integer.parseInt(arr[i]);
                }
                catch(NumberFormatException ex){
                    continue;
                }
            }
            System.out.println(total);
        }
       // V v = new V();
       // System.out.println(v);
        //int x [] = {10,20,30};
        //System.out.println(x);
       // if(arr.length)
    //    int a = Integer.parseInt(arr[0]);
    //    int b = Integer.parseInt(arr[1]);
    //    int c = a + b;
    //    System.out.println(c);

 }
}
