public class Conditional {
    public static void main(String[] args) {
        int a= 10;
        int b = 20;
        //if(true){
        if(a>b){
            System.out.println("A is Greater");
        }
        else{
            System.out.println("B is Greater");
        }
        final int SUNDAY = 1;
        final int MONDAY = 2;
        //int day = 1;
        String day = "Sunday";
        switch(day){
            default:
            System.out.println("Wrong Day");
            break;
            case "Sunday":
            System.out.println("This is a Fun Day");
            //break;
            case "Monday":
            System.out.println("Boring Day");
            //break;


        }
    }
}
