package recursion_demo;

public class Fact {
	
	// input : 5! - 5 * 4 * 3 * 2 * 1
	// Big Problem - Fact 5!
	static int fact(int n) {
		//Termination Case
		if(n == 1) {
			return 1;
		}
		// Small Problem
		int smallResult = fact(n-1);
		return n * smallResult;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int result = fact(5);
		System.out.println(result);

	}

}
