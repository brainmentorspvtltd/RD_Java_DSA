package recursion_demo;

public class Pattern {
	static void printStar(int star) {
		if(star ==0) {
			return ;
		}
		System.out.print("*");
		printStar(star - 1);
		
	}
	static void printRow(int row, int star){
		if(row ==0) {
			return ;
		}
		printStar(star);
		System.out.println();
		printRow(row-1, star - 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 5;
		int star = 5;
		printRow(n, star);

	}

}
