package recursion_demo;

import java.util.ArrayList;

public class SubSequenceDemo {
	static ArrayList<String> subSequence(String str){
		
		// Termination Case
		if(str.length()==0) {
			ArrayList<String> list =new ArrayList<>();
			list.add(" ");
			return list;
		}
		
		// Get the First Char
		char firstChar = str.charAt(0);
		String remString = str.substring(1);
		ArrayList<String> finalResult = new ArrayList<>();
		ArrayList<String> subResult = subSequence(remString); // Small Problem
		for(String s : subResult) {
			finalResult.add(s);
			finalResult.add(firstChar + s);
		}
		return finalResult;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(subSequence("amit"));

	}

}
