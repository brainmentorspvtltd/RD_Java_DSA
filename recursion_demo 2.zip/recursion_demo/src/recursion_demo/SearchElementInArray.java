package recursion_demo;

public class SearchElementInArray {
	
	static int search(int arr[], int search , int index) {
		if(arr.length == index) {
			return -1;
		}
		if(arr[index] == search) {
			return index;
		}
		return search(arr, search , index + 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr [] = {90,10,30,55, 66,77};
		System.out.println(search(arr, 77, 0)==-1?"Not Found ":" Found");

	}

}
