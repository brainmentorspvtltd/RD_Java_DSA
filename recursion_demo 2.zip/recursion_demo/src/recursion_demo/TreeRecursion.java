package recursion_demo;

public class TreeRecursion {
	
	static void show(int x) {
		System.out.println(x);
		if(x>=3) {
			return ;
		}
		show(x+1);
		show(x+2);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		show(0);

	}

}
