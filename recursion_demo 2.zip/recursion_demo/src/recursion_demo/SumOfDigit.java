package recursion_demo;

public class SumOfDigit {
	static int sumOfDigit(int num, int sum) {
		//Termination Case
		if(num ==0) {
			return sum;
		}
		// Processing Logic
		sum = sum + num%10;
		// Small Problem
		return sumOfDigit(num/10, sum);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(sumOfDigit(123, 0));

	}

}
