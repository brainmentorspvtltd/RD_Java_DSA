package recursion_demo;

public class Fibo {
	static int fibo(int num) {
		if(num<=1) {
			return num;
		}
		int firstTerm = fibo(num-1);
		int secondTerm = fibo(num-2);
		int result= firstTerm + secondTerm;
		
		return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(fibo(10));
	}

}
