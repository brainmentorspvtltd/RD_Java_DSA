package recursion_demo;

public class Print {
	// 5, 4, 3, 2, 1
	
	// 1,2,3,4,5
	
	static void printIt2(int n) {
		// Termination case
		if(n==0) {
			return ; // exit from the current call and move to the calling point
		}
		
		printIt2(n-1); // Small Problem - Head recursion
		System.out.println(n); // Logic
	}

	
	// What Problem i  need to Solve 
	static void printIt(int n) {
		// Termination case
		if(n==0) {
			return ; // exit from the current call and move to the calling point
		}
		System.out.println(n); // Logic
		printIt(n-1); // Small Problem - Tail Recursion
	}
		// 5 to 1 and 1 to 5 - Linear Recursion
	static void printIt3(int n) {
		// Termination case
		if(n==0) {
			return ; // exit from the current call and move to the calling point
		}
		System.out.println(n); // Pre Logic
		printIt3(n-1); // Small Problem
		System.out.println(n); // Post Logic
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printIt3(5);

	}

}
