package recursion_demo;

public class StringReverse {
	static String reverse(String str){
		if(str.length()==1) {
			return String.valueOf(str.charAt(0));
		}
		return reverse(str.substring(1)) + str.charAt(0); // Small Problem + Processing Logic
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(reverse("ABCD"));

	}

}
