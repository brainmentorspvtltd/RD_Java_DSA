package recursion_demo;

public class StackFlow {
	static int num =0;
	static int show(int n) {
		if(n>0) {
			num++;
			return show(n-1) + num;
		}
		return 0;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(show(5));

	}

}
